<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" />
    <link href="fontawesome/css/all.min.css" rel="stylesheet" />
    <link href="css/templatemo-comparto.css" rel="stylesheet" />
    <title><?=$titre?></title>
<!--

Comparto TemplateMo

https://templatemo.com/tm-544-comparto

-->
</head>

<body>
    <!-- Back to top button -->
    <a id="button"><i class="fas fa-angle-up fa-2x"></i></a>
    <div class="container-fluid">
        <div class="tm-site-header tm-mb-1">
            <div class="tm-site-name-container tm-bg-color-1">
                <h1 class="tm-text-white">Mon Blog</h1>
            </div>
            <div class="tm-nav-container tm-bg-color-8">
                <nav class="tm-nav" id="tm-nav">
                    <ul>
                        <li class="tm-nav-item current">
                            <a href="#about" class="tm-nav-link">
                                <span class="tm-mb-1">.01</span>
                                <span>About</span>
                            </a>
                        </li>
                        <li class="tm-nav-item">
                            <a href="#services" class="tm-nav-link">
                                <span class="tm-mb-1">.02</span>
                                <span>Activities</span>
                            </a>
                        </li>
                        <li class="tm-nav-item">
                            <a href="#gallery" class="tm-nav-link">
                                <span class="tm-mb-1">.03</span>
                                <span>Gallery</span>
                            </a>
                        </li>
                        <li class="tm-nav-item">
                            <a href="#contact" class="tm-nav-link">
                                <span class="tm-nav-text tm-mb-1">.04</span>
                                <span class="tm-nav-text">Contact</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <section class="tm-mb-1" id="about">
            <div class="tm-row tm-about-row">
                <div class="tm-section-1-l">
                    <img src="img/comparto-image-01.jpg" alt="About image" class="tm-img-responsive">
                </div>
                <article class="tm-section-1-r tm-bg-color-8">
                    <h2 class="tm-mb-2 tm-title-color">Bienvenu</h2>
                    <?=$contenu?>
                    
                    <a href="#services" class="tm-btn tm-btn-1 tm-link-to-services">More Detail</a>
                </article>
            </div>
        </section>
        
        <section class="tm-mb-1 tm-row tm-services-row" id="services">
            <div class="tm-section-2-r">
                <img src="img/comparto-image-02.jpg" alt="Services image" class="tm-img-responsive">
            </div>
        </section>
        <section class="tm-bg-color-4 tm-mb-3 tm-gallery-section" id="gallery">
            <div class="tm-gallery-header">
                <h2 class="tm-mb-1 text-right"> The Gallery Section</h2>
                <ul class="tm-gallery-filter tabs clearfix filters-button-group">
                    <li><a role="button" href="#" class="active" data-filter="*">Show All</a></li>
                    . <li><a role="button" href="#" data-filter=".nature">Nature</a></li>
                    . <li><a role="button" href="#" data-filter=".animals">Animals</a></li>
                    . <li><a role="button" href="#" data-filter=".people">People</a></li>
                </ul>
            </div>
            <div class="tm-gallery-outer">
                <div class="tm-gallery" id="tm-gallery">
                    <div class="tm-gallery-item nature">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-01.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Too <span>CSS</span></h2>
                                <p>It is a great blog you should explore.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item animals">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-02.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Templates</h2>
                                <p>best templates come from TemplateMo website.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item nature">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-03.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Web <span>Design</span></h2>
                                <p>This is our special design work.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item nature">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-04.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Free <span>HTML</span></h2>
                                <p>HTML layouts are easy to edit.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item animals">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-05.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Just <span>Art</span></h2>
                                <p>You can create your own art website.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item animals">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-06.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Pro <span>Display</span></h2>
                                <p>You can make your artwork gallery.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item peopl">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-07.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>The <span>Nature</span></h2>
                                <p>You can create your own HTML website.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item people">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-08.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Color <span>Art</span></h2>
                                <p>You can create your own CSS website.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item people">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-09.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Take it <span>easy</span></h2>
                                <p>You can create your own art gallery.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="tm-gallery-item people">
                        <figure class="effect-bubba">
                            <img src="img/gallery/gallery-item-10.jpg" alt="Gallery item" class="tm-img-responsive" />
                            <figcaption>
                                <h2>Share <span>This</span></h2>
                                <p>You can make your own image gallery.</p>
                                <a href="#">View more</a>
                            </figcaption>
                        </figure>
                    </div>
                </div>
            </div>
        </section> <!-- Gallery -->
        <section id="contact" class="tm-bg-color-5 tm-mb-3">
            <h2 class="tm-text-white tm-contact-title"> Contact Us</h2>
            <div class="tm-bg-color-white tm-contact-main">
                <div class="map-outer">
                    <div class="gmap-canvas">
                        <!-- How to change your own map point
                            1. Go to Google Maps
                            2. Click on your location point
                            3. Click "Share" and choose "Embed map" tab
                            4. Copy only URL and paste it within the src="" field below
                        -->
                        <iframe width="100%" height="400" id="gmap-canvas"
                            src="https://maps.google.com/maps?q=Av.+Lúcio+Costa,+Rio+de+Janeiro+-+RJ,+Brazil&t=&z=13&ie=UTF8&iwloc=&output=embed"
                            frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                    </div>
                </div>
                <div class="contact-form-outer">
                    <form id="contact-form" action="" method="POST" class="tm-bg-color-6 tm-contact-form">
                        <div class="form-group">
                            <input type="text" name="name" class="form-control" placeholder="Name" required="" />
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" class="form-control" placeholder="Email" required="" />
                        </div>
                        <div class="form-group">
                            <textarea rows="4" name="message" class="form-control" placeholder="Message..."
                                required=""></textarea>
                        </div>
                        <div>
                            <button type="submit" class="ml-auto tm-btn tm-btn-3">
                                Send
                            </button>
                        </div>
                    </form>
                </div>
                
            
        </section>
        <div class="tm-mb-4 text-center tm-social-s">
            <a href="https://fb.com/templatemo" class="tm-social-link"><i class="fab fa-facebook tm-social-icon"></i></a>
            <a href="https://instagram.com" class="tm-social-link"><i class="fab fa-instagram tm-social-icon"></i></a>
            <a href="https://twitter.com" class="tm-social-link"><i class="fab fa-twitter tm-social-icon"></i></a>
            <a href="https://youtube.com" class="tm-social-link"><i class="fab fa-youtube tm-social-icon"></i></a>
        </div>
        <footer class="text-center tm-mb-1">
            <p>Copyright &copy; 2020 Comparto Studio 
            
            - Design: <a rel="nofollow noopener" href="https://templatemo.com" target="_blank">TemplateMo</a></p>
        </footer>
    </div> <!-- .container -->
    <script src="js/jquery.min.js"></script> <!-- https://jquery.com/download/ -->
    <script src="js/imagesloaded.pkgd.min.js"></script> <!-- https://imagesloaded.desandro.com/ -->
    <script src="js/isotope.pkgd.min.js"></script> <!-- https://isotope.metafizzy.co/ -->
    <script src="js/jquery.singlePageNav.min.js"></script> <!-- https://github.com/ChrisWojcik/single-page-nav -->
    <script>

        // Scroll to Top button
        var btn = $('#button');

        $(window).scroll(function () {
            if ($(window).scrollTop() > 300) {
                btn.addClass('show');
            } else {
                btn.removeClass('show');
            }
        });

        btn.on('click', function (e) {
            e.preventDefault();
            $('html, body').animate({ scrollTop: 0 }, '300');
        });

        // DOM is ready
        $(function () {
            // Single Page Nav
            $('#tm-nav').singlePageNav({ speed: 600 });

            // Smooth Scroll (https://css-tricks.com/snippets/jquery/smooth-scrolling/)
            $('a[href*="#"]')
                // Remove links that don't actually link to anything
                .not('[href="#"]')
                .not('[href="#0"]')
                .click(function (event) {
                    // On-page links
                    if (
                        location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '')
                        &&
                        location.hostname == this.hostname
                    ) {
                        // Figure out element to scroll to
                        var target = $(this.hash);
                        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                        // Does a scroll target exist?
                        if (target.length) {
                            // Only prevent default if animation is actually gonna happen
                            event.preventDefault();
                            $('html, body').animate({
                                scrollTop: target.offset().top
                            }, 600, function () {
                                // Callback after animation
                                // Must change focus!
                                var $target = $(target);
                                $target.focus();
                                if ($target.is(":focus")) { // Checking if the target was focused
                                    return false;
                                } else {
                                    $target.attr('tabindex', '-1'); // Adding tabindex for elements not focusable
                                    $target.focus(); // Set focus again
                                };
                            });
                        }
                    }
                });

            /* Isotope Gallery */

            // init isotope
            var $gallery = $(".tm-gallery").isotope({
                itemSelector: ".tm-gallery-item",
                layoutMode: "fitRows"
            });
            // layout Isotope after each image loads
            $gallery.imagesLoaded().progress(function () {
                $gallery.isotope("layout");
            });

            $(".filters-button-group").on("click", "a", function () {
                var filterValue = $(this).attr("data-filter");
                $gallery.isotope({ filter: filterValue });
            });

            $(".tabgroup > div").hide();
            $(".tabgroup > div:first-of-type").show();
            $(".tabs a").click(function (e) {
                e.preventDefault();
                var $this = $(this),
                    tabgroup = "#" + $this.parents(".tabs").data("tabgroup"),
                    others = $this
                        .closest("li")
                        .siblings()
                        .children("a"),
                    target = $this.attr("href");
                others.removeClass("active");
                $this.addClass("active");
            });
        });
    </script>
</body>
</html>