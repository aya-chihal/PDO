<?php
// Accès aux données
require_once 'Modele.php';
$billets = getBillets();
//affichage
require 'vueAccueil.php';